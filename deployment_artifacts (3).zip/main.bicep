targetScope = 'resourceGroup'

@description('Environment name used for resource prefix.')
param environmentName string = 'dev'

@description('Location for resources. Defaults to the resource group location.')
param location string = resourceGroup().location

@description('UTC timestamp to ensure unique resource naming.')
param baseTime string = utcNow()
@description('Tags to associate with resources.')
param tags object = {}

@description('REQUIRED: Azure AD UPN in the target tenant for Fabric Capacity admin assignment')
param adminEmail string

@secure()
@minLength(16)
@description('REQUIRED: SQL admin password. Must be at least 16 characters and include uppercase, lowercase, number, and special character. Must not contain the admin username or common words.')
param sqlAdminPassword string

var prefix = '${environmentName}-${uniqueString(resourceGroup().id, subscription().id, baseTime)}'

// Location fallbacks for region-specific resources
var sqlMiLocation = contains(['eastus', 'eastus2', 'westus', 'westus2', 'centralus'], location) ? location : 'eastus'
var fabricLocation = contains(['eastus', 'eastus2', 'westus2', 'northeurope'], location) ? location : 'eastus'
var openAiLocation = contains(['eastus', 'eastus2', 'centralus', 'westus', 'northcentralus', 'southcentralus'], location) ? location : 'eastus'

// Azure Database Migration Service
resource dms 'Microsoft.DataMigration/services@2022-11-01' = {
  name: take(replace('dms${prefix}', '-', ''), 24)
  location: location
  sku: {
    name: 'Standard'
  }
  properties: {}
}

// ExpressRoute Circuit
resource expressRoute 'Microsoft.Network/expressRouteCircuits@2023-06-01' = {
  name: take(replace('er${prefix}', '-', ''), 24)
  location: location
  sku: {
    name: 'Standard'
    tier: 'Standard'
  }
  properties: {
    allowClassicOperations: false
    globalReachEnabled: true
  }
}

// SQL Managed Instance prerequisites
resource nsgSqlMI 'Microsoft.Network/networkSecurityGroups@2023-06-01' = {
  name: 'nsg-${prefix}'
  location: location
  properties: {}
}

resource routeTableSqlMI 'Microsoft.Network/routeTables@2023-06-01' = {
  name: 'route-${prefix}'
  location: location
  properties: {}
}

resource vnetSqlMI 'Microsoft.Network/virtualNetworks@2023-06-01' = {
  name: 'vnet-${prefix}'
  location: location
  properties: {
    addressSpace: {
      addressPrefixes: [
        '10.0.0.0/16'
      ]
    }
    subnets: [
      {
        name: 'snet-sqlmi'
        properties: {
          addressPrefix: '10.0.0.0/24'
          networkSecurityGroup: {
            id: nsgSqlMI.id
          }
          routeTable: {
            id: routeTableSqlMI.id
          }
          delegations: [
            {
              name: 'sqlmi'
              properties: {
                serviceName: 'Microsoft.Sql/managedInstances'
              }
            }
          ]
        }
      }
    ]
  }
}

var sqlMiSubnetId = resourceId('Microsoft.Network/virtualNetworks/subnets', vnetSqlMI.name, 'snet-sqlmi')

// SQL Managed Instance
resource sqlMi 'Microsoft.Sql/managedInstances@2023-08-01' = {
  name: take(replace('mi${prefix}', '-', ''), 24)
  location: sqlMiLocation
  sku: {
    name: 'GP_Gen5'
    tier: 'GeneralPurpose'
    family: 'Gen5'
    capacity: 8
  }
  properties: {
    subnetId: sqlMiSubnetId
    administratorLogin: 'sqladmin'
    administratorLoginPassword: sqlAdminPassword
    storageSizeInGB: 1024
    dataLicenseType: 'BasePrice'
    zoneRedundant: true
  }
  dependsOn: [
    nsgSqlMI
    routeTableSqlMI
    vnetSqlMI
  ]
}

// SQL MI Failover Group
resource sqlMiFailoverGroup 'Microsoft.Sql/managedInstances/failoverGroups@2023-08-01' = {
  parent: sqlMi
  name: take(replace('fg${prefix}', '-', ''), 24)
  location: sqlMiLocation
  properties: {
    readWriteEndpoint: {
      failoverPolicy: 'Automatic'
      failoverWithDataLossGracePeriodMinutes: 60
    }
    partnerRegions: [
      {
        location: 'westeurope'
        replicationRole: 'Secondary'
      }
    ]
  }
}

// Fabric Capacity
resource fabricCapacity 'Microsoft.Fabric/capacities@2023-11-01' = {
  name: take(replace('fc${prefix}', '-', ''), 63)
  location: fabricLocation
  sku: {
    name: 'F2'
    tier: 'Fabric'
  }
  properties: {
    administration: {
      members: [
        toLower(adminEmail)
      ]
    }
  }
  dependsOn: [
    dms
    expressRoute
    sqlMi
    sqlMiFailoverGroup
  ]
}

// Microsoft Foundry Account
resource foundryAccount 'Microsoft.CognitiveServices/accounts@2025-06-01' = {
  name: take(replace('foundry${prefix}', '-', ''), 24)
  location: openAiLocation
  kind: 'AIServices'
  sku: {
    name: 'S0'
  }
  identity: { type: 'SystemAssigned' }
  properties: {
    allowProjectManagement: true
    customSubDomainName: take(replace('foundry${prefix}', '-', ''), 24)
    disableLocalAuth: false
    publicNetworkAccess: 'Enabled'
  }
}

// Foundry Model Deployment
resource foundryDeployment 'Microsoft.CognitiveServices/accounts/deployments@2025-06-01' = {
  parent: foundryAccount
  name: 'gpt-5-mini'
  sku: {
    name: 'GlobalStandard'
    capacity: 10
  }
  properties: {
    model: {
      format: 'OpenAI'
      name: 'gpt-5-mini'
      version: '2025-08-07'
    }
  }
}

// Foundry Project
resource foundryProject 'Microsoft.CognitiveServices/accounts/projects@2025-06-01' = {
  parent: foundryAccount
  name: take(replace('proj${prefix}', '-', ''), 24)
  location: openAiLocation
  dependsOn: [
    foundryDeployment
  ]
  properties: {
    displayName: 'Microsoft Foundry Project'
    description: 'Microsoft Foundry Project'
  }
}

// The following resources are missing their corresponding `resource` declarations:

// OneLake
resource oneLake 'Microsoft.Fabric/accounts@2023-11-01' = {
  name: take(replace('onelake${prefix}', '-', ''), 24)
  location: fabricLocation
  sku: {
    name: 'OneLake'
    tier: 'Fabric'
  }
}

// Lakehouse
resource lakehouse 'Microsoft.Fabric/workspaces@2023-11-01' = {
  name: take(replace('lakehouse${prefix}', '-', ''), 24)
  location: fabricLocation
  sku: {
    name: 'Standard'
    tier: 'Fabric'
  }
}

// Fabric IQ
resource fabricIQ 'Microsoft.Fabric/capacities/features@2023-11-01' = {
  parent: fabricCapacity
  name: 'fabric-iq'
  properties: {
    featureType: 'IQ'
  }
}

// Ontology
resource ontology 'Microsoft.Fabric/ontologies@2023-11-01' = {
  name: take(replace('ontology${prefix}', '-', ''), 24)
  location: fabricLocation
  properties: {
    description: 'Ontology Resource'
  }
}

// Microsoft Fabric IQ
resource fabricIQAccount 'Microsoft.Fabric/accounts@2023-11-01' = {
  name: take(replace('fabricIQ${prefix}', '-', ''), 24)
  location: fabricLocation
  sku: {
    name: 'IQ'
    tier: 'Fabric'
  }
}