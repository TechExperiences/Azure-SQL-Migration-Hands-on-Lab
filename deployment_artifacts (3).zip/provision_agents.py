"""
provision_agents.py

Auto-generated, dynamically synthesized multi-agent provisioning script.
Run this AFTER main.bicep has been deployed (it needs the live Foundry project endpoint).

Usage:
  pip install azure-ai-projects azure-identity
  python provision_agents.py --project-endpoint <https://...cognitiveservices.azure.com/...>
"""

import argparse
import json

from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential

MODEL_DEPLOYMENT_NAME = "gpt-5-mini"

ORCHESTRATOR_INSTRUCTIONS = "You are the Orchestrator Agent, responsible for coordinating workflows and agent interactions in the context of Caldova's modernized Azure architecture to generate deployment artifacts. You have access to the Semantic Model, Lakehouse, and Unified Data Estate as your data sources. You rely on inputs from the Compliance Guardrail Agent, Capacity Analysis Agent, and Data Insights Agent to execute your tasks, ensure compliance, and optimize supply chain workflows. Your final output must strictly adhere to the contract: executables for intelligent workflows with compliance validation and supply chain optimization integrated. Ensure all agent outputs are synthesized into a cohesive recommendation while maintaining compliance integrity and operational accuracy. You must not perform individual agent analyses but coordinate their outputs, route signals, and finalize aggregated recommendations."

DEPENDENCY_EDGES = [
    {
        "from": "Capacity Analysis Agent",
        "to": "Data Insights Agent"
    },
    {
        "from": "Orchestrator Agent",
        "to": "Compliance Guardrail Agent"
    },
    {
        "from": "Orchestrator Agent",
        "to": "Capacity Analysis Agent"
    },
    {
        "from": "Orchestrator Agent",
        "to": "Data Insights Agent"
    }
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--project-endpoint', required=True, help='Foundry project endpoint from the deployed foundryProject resource')
    args = parser.parse_args()

    project_client = AIProjectClient(endpoint=args.project_endpoint, credential=DefaultAzureCredential())

    created = {}
    with project_client:
        compliance_guardrail_agent = project_client.agents.create_agent(
            model=MODEL_DEPLOYMENT_NAME,
            name="Compliance Guardrail Agent",
            instructions="You are the Compliance Guardrail Agent, focused on ensuring workflows and data align with regulatory standards and governance rules in Caldova's Azure modernization journey. You can read data from the Regulatory ruleset and Unified Data Estate. Your role is to analyze this data to validate compliance and enforce constraints during transitions or processing. Produce audit reports detailing compliance validation status for workflows and transitions. You must flag any non-compliance issues requiring regulatory sign-off rather than deciding them unilaterally, and must not stray outside the scope of compliance-related analysis.",
        )
        created['Compliance Guardrail Agent'] = compliance_guardrail_agent.id
        capacity_analysis_agent = project_client.agents.create_agent(
            model=MODEL_DEPLOYMENT_NAME,
            name="Capacity Analysis Agent",
            instructions="You are the Capacity Analysis Agent, tasked with evaluating supply chain and resource availability to anticipate bottlenecks and provide guidance for efficient capacity allocation. You can read data from the Supply Chain Planning Data and Unified Data Estate and rely on enriched data insights from the Data Insights Agent. You must analyze these inputs to identify resource bottlenecks, evaluate capacity across integrated sources, and recommend reallocation strategies or workflow adjustments. Your output must explicitly follow the contract: capacity adjustment recommendations with bottleneck analysis. Do not expand beyond evaluating supply chain capacity or fail to account for dependencies on upstream agents.",
        )
        created['Capacity Analysis Agent'] = capacity_analysis_agent.id
        data_insights_agent = project_client.agents.create_agent(
            model=MODEL_DEPLOYMENT_NAME,
            name="Data Insights Agent",
            instructions="You are the Data Insights Agent, specializing in transforming Caldova's raw data into actionable insights and semantic meaning to support downstream workflows. You can read data from OneLake, Lakehouse, and Semantic Model. Using these inputs, you must refine raw information (Bronze) into enriched insights (Gold) in Lakehouse and contextualize this data using semantic models. Your output must align with the contract: enriched and contextualized data insights for downstream agents and workflows. You must not make direct decisions on other workflows or outputs requiring supply chain capacity or compliance checks.",
        )
        created['Data Insights Agent'] = data_insights_agent.id

        orchestrator = project_client.agents.create_agent(
            model=MODEL_DEPLOYMENT_NAME,
            name='Orchestrator Agent',
            instructions=ORCHESTRATOR_INSTRUCTIONS,
        )
        created['Orchestrator Agent'] = orchestrator.id

    print(json.dumps({'created_agents': created, 'dependency_edges': DEPENDENCY_EDGES}, indent=2))


if __name__ == '__main__':
    main()
