CREATE LOGIN sqladmin WITH PASSWORD = 'YourPassword@123';
ALTER SERVER ROLE sysadmin ADD MEMBER sqladmin;