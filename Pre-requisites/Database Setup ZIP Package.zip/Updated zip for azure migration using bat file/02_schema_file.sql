USE [master];
GO

-- Drop database if it already exists
IF EXISTS (SELECT 1 FROM sys.databases WHERE name = N'Retail_Ontology')
BEGIN
    ALTER DATABASE [Retail_Ontology] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE [Retail_Ontology];
END
GO

-- Create database (uses default file locations)
CREATE DATABASE [Retail_Ontology];
GO

USE [Retail_Ontology];
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

-- ============================================================
-- TABLES (ordered by dependency - parent tables first)
-- ============================================================

CREATE TABLE [dbo].[regions](
    [reg_id] [varchar](20) NOT NULL,
    [reg_name] [varchar](50) NULL,
    [coun_code] [varchar](10) NULL,
    [time_name] [varchar](50) NULL,
    [is_cold_chain_requ] [bit] NULL,
    CONSTRAINT [PK_regions] PRIMARY KEY CLUSTERED ([reg_id] ASC)
);
GO

CREATE TABLE [dbo].[product_categories](
    [prod_cat_id] [varchar](20) NOT NULL,
    [cat_name] [varchar](100) NULL,
    [depa_name] [varchar](100) NULL,
    [is_peri] [bit] NULL,
    [shelf_life_days] [int] NULL,
    CONSTRAINT [PK_product_categories] PRIMARY KEY CLUSTERED ([prod_cat_id] ASC)
);
GO

CREATE TABLE [dbo].[carriers](
    [car_id] [varchar](20) NOT NULL,
    [car_name] [varchar](100) NULL,
    [serv_level] [varchar](50) NULL,
    [has_cold_chain_capa] [bit] NULL,
    [supp_ph] [varchar](30) NULL,
    CONSTRAINT [PK_carriers] PRIMARY KEY CLUSTERED ([car_id] ASC)
);
GO

CREATE TABLE [dbo].[customers](
    [cust_id] [varchar](20) NOT NULL,
    [reg_id] [varchar](20) NULL,
    [cust_email] [varchar](100) NULL,
    [loya_tier] [varchar](20) NULL,
    [is_active_cust] [bit] NULL,
    [sign_up_dt] [datetime2](7) NULL,
    [life_val_amt] [decimal](10, 2) NULL,
    [cust_profile_image] [varbinary](max) NULL,
    [profile_image_url] [nvarchar](500) NULL,
    [identity_document] [varbinary](max) NULL,
    [preferences_json] [nvarchar](max) NULL,
    [customer_settings] [xml] NULL,
    [digital_signature] [varbinary](max) NULL,
    [linkedin_url] [nvarchar](300) NULL,
    [website_url] [nvarchar](300) NULL,
    CONSTRAINT [PK_customers] PRIMARY KEY CLUSTERED ([cust_id] ASC),
    CONSTRAINT [FK_customers_regions] FOREIGN KEY ([reg_id]) REFERENCES [dbo].[regions] ([reg_id]),
    CONSTRAINT [CK_customers_life_val] CHECK ([life_val_amt] >= 0)
);
GO

CREATE TABLE [dbo].[products](
    [prod_id] [varchar](20) NOT NULL,
    [prod_cat_id] [varchar](20) NULL,
    [sku] [varchar](20) NULL,
    [prod_name] [varchar](255) NULL,
    [brand_name] [varchar](100) NULL,
    [is_disc] [bit] NULL,
    [launch_dt] [datetime2](7) NULL,
    [unit_cost_amt] [decimal](10, 2) NULL,
    CONSTRAINT [PK_products] PRIMARY KEY CLUSTERED ([prod_id] ASC),
    CONSTRAINT [FK_products_categories] FOREIGN KEY ([prod_cat_id]) REFERENCES [dbo].[product_categories] ([prod_cat_id]),
    CONSTRAINT [CK_products_unit_cost] CHECK ([unit_cost_amt] >= 0)
);
GO

CREATE TABLE [dbo].[warehouses](
    [wh_id] [varchar](20) NOT NULL,
    [reg_id] [varchar](20) NULL,
    [wh_name] [varchar](50) NULL,
    [addr_line1] [varchar](100) NULL,
    [city_name] [varchar](50) NULL,
    [state_or_prov] [varchar](50) NULL,
    [postal_code] [varchar](50) NULL,
    [is_cross_dock] [bit] NULL,
    CONSTRAINT [PK_warehouses] PRIMARY KEY CLUSTERED ([wh_id] ASC),
    CONSTRAINT [FK_warehouses_regions] FOREIGN KEY ([reg_id]) REFERENCES [dbo].[regions] ([reg_id])
);
GO

CREATE TABLE [dbo].[stores](
    [str_id] [varchar](20) NOT NULL,
    [reg_id] [varchar](20) NULL,
    [str_name] [varchar](50) NULL,
    [str_type] [varchar](50) NULL,
    [open_dt] [datetime2](7) NULL,
    CONSTRAINT [PK_stores] PRIMARY KEY CLUSTERED ([str_id] ASC),
    CONSTRAINT [FK_stores_regions] FOREIGN KEY ([reg_id]) REFERENCES [dbo].[regions] ([reg_id])
);
GO

CREATE TABLE [dbo].[orders](
    [ord_id] [varchar](20) NOT NULL,
    [cust_id] [varchar](20) NULL,
    [reg_id] [varchar](20) NULL,
    [ord_dt] [datetime2](7) NULL,
    [ord_status] [varchar](20) NULL,
    [is_expe] [bit] NULL,
    [ord_total_amt] [decimal](10, 2) NULL,
    [paym_method_type] [varchar](20) NULL,
    CONSTRAINT [PK_orders] PRIMARY KEY CLUSTERED ([ord_id] ASC),
    CONSTRAINT [FK_orders_customers] FOREIGN KEY ([cust_id]) REFERENCES [dbo].[customers] ([cust_id]),
    CONSTRAINT [FK_orders_regions] FOREIGN KEY ([reg_id]) REFERENCES [dbo].[regions] ([reg_id]),
    CONSTRAINT [CK_orders_total] CHECK ([ord_total_amt] >= 0)
);
GO

CREATE TABLE [dbo].[order_lines](
    [ord_ln_id] [varchar](20) NOT NULL,
    [ord_id] [varchar](20) NULL,
    [prod_id] [varchar](20) NULL,
    [qty] [int] NULL,
    [unit_price_amt] [decimal](10, 2) NULL,
    [ln_total_amt] [decimal](10, 2) NULL,
    CONSTRAINT [PK_order_lines] PRIMARY KEY CLUSTERED ([ord_ln_id] ASC),
    CONSTRAINT [FK_order_lines_orders] FOREIGN KEY ([ord_id]) REFERENCES [dbo].[orders] ([ord_id]),
    CONSTRAINT [FK_order_lines_products] FOREIGN KEY ([prod_id]) REFERENCES [dbo].[products] ([prod_id]),
    CONSTRAINT [CK_order_lines_qty] CHECK ([qty] >= 0),
    CONSTRAINT [CK_order_lines_unit_price] CHECK ([unit_price_amt] >= 0),
    CONSTRAINT [CK_order_lines_total] CHECK ([ln_total_amt] >= 0)
);
GO

CREATE TABLE [dbo].[returns](
    [rtn_id] [varchar](20) NOT NULL,
    [ord_id] [varchar](20) NULL,
    [prod_id] [varchar](20) NULL,
    [rtn_dt] [datetime2](7) NULL,
    [rtn_rsn] [varchar](50) NULL,
    [rfnd_amt] [decimal](10, 2) NULL,
    CONSTRAINT [PK_returns] PRIMARY KEY CLUSTERED ([rtn_id] ASC),
    CONSTRAINT [FK_returns_orders] FOREIGN KEY ([ord_id]) REFERENCES [dbo].[orders] ([ord_id]),
    CONSTRAINT [FK_returns_products] FOREIGN KEY ([prod_id]) REFERENCES [dbo].[products] ([prod_id]),
    CONSTRAINT [CK_returns_rfnd] CHECK ([rfnd_amt] >= 0)
);
GO

CREATE TABLE [dbo].[shipments](
    [shp_id] [varchar](20) NOT NULL,
    [ord_id] [varchar](20) NULL,
    [car_id] [varchar](20) NULL,
    [wh_id] [varchar](20) NULL,
    [reg_id] [varchar](20) NULL,
    [trac_num] [varchar](20) NULL,
    [shp_status] [varchar](20) NULL,
    [ship_dt] [datetime2](7) NULL,
    [est_deli_dt] [datetime2](7) NULL,
    [act_deli_dt] [datetime2](7) NULL,
    CONSTRAINT [PK_shipments] PRIMARY KEY CLUSTERED ([shp_id] ASC),
    CONSTRAINT [FK_shipments_orders] FOREIGN KEY ([ord_id]) REFERENCES [dbo].[orders] ([ord_id]),
    CONSTRAINT [FK_shipments_carriers] FOREIGN KEY ([car_id]) REFERENCES [dbo].[carriers] ([car_id]),
    CONSTRAINT [FK_shipments_warehouses] FOREIGN KEY ([wh_id]) REFERENCES [dbo].[warehouses] ([wh_id]),
    CONSTRAINT [FK_shipments_regions] FOREIGN KEY ([reg_id]) REFERENCES [dbo].[regions] ([reg_id])
);
GO

CREATE TABLE [dbo].[inventories](
    [inv_id] [varchar](20) NOT NULL,
    [prod_id] [varchar](20) NULL,
    [wh_id] [varchar](20) NULL,
    [reg_id] [varchar](20) NULL,
    [sfty_stock_qty] [int] NULL,
    [reord_pt_qty] [int] NULL,
    [lead_t_days] [int] NULL,
    CONSTRAINT [PK_inventories] PRIMARY KEY CLUSTERED ([inv_id] ASC),
    CONSTRAINT [FK_inventories_products] FOREIGN KEY ([prod_id]) REFERENCES [dbo].[products] ([prod_id]),
    CONSTRAINT [FK_inventories_warehouses] FOREIGN KEY ([wh_id]) REFERENCES [dbo].[warehouses] ([wh_id]),
    CONSTRAINT [FK_inventories_regions] FOREIGN KEY ([reg_id]) REFERENCES [dbo].[regions] ([reg_id]),
    CONSTRAINT [CK_inventories_sfty_stock] CHECK ([sfty_stock_qty] >= 0),
    CONSTRAINT [CK_inventories_reord_pt] CHECK ([reord_pt_qty] >= 0)
);
GO

CREATE TABLE [dbo].[demand_signals](
    [dem_signal_id] [varchar](20) NOT NULL,
    [prod_id] [varchar](20) NULL,
    [reg_id] [varchar](20) NULL,
    [dem_chn] [varchar](20) NULL,
    [signal_src_sys] [varchar](50) NULL,
    CONSTRAINT [PK_demand_signals] PRIMARY KEY CLUSTERED ([dem_signal_id] ASC),
    CONSTRAINT [FK_demand_signals_products] FOREIGN KEY ([prod_id]) REFERENCES [dbo].[products] ([prod_id]),
    CONSTRAINT [FK_demand_signals_regions] FOREIGN KEY ([reg_id]) REFERENCES [dbo].[regions] ([reg_id])
);
GO

CREATE TABLE [dbo].[forecasts](
    [fcst_id] [varchar](20) NOT NULL,
    [prod_id] [varchar](20) NULL,
    [reg_id] [varchar](20) NULL,
    [dem_signal_id] [varchar](20) NULL,
    [fcst_hor_days] [int] NULL,
    [fcst_mdl_name] [varchar](30) NULL,
    CONSTRAINT [PK_forecasts] PRIMARY KEY CLUSTERED ([fcst_id] ASC),
    CONSTRAINT [FK_forecasts_products] FOREIGN KEY ([prod_id]) REFERENCES [dbo].[products] ([prod_id]),
    CONSTRAINT [FK_forecasts_regions] FOREIGN KEY ([reg_id]) REFERENCES [dbo].[regions] ([reg_id]),
    CONSTRAINT [FK_forecasts_demand_signals] FOREIGN KEY ([dem_signal_id]) REFERENCES [dbo].[demand_signals] ([dem_signal_id])
);
GO

CREATE TABLE [dbo].[Promotions](
    [promo_id] [varchar](12) NOT NULL,
    [prod_id] [varchar](20) NULL,
    [reg_id] [varchar](20) NULL,
    [promo_name] [varchar](50) NULL,
    [start_dt] [datetime2](7) NULL,
    [end_dt] [datetime2](7) NULL,
    [disc_pct] [decimal](5, 4) NULL,
    [is_active_promo] [bit] NULL,
    CONSTRAINT [PK_Promotions] PRIMARY KEY CLUSTERED ([promo_id] ASC),
    CONSTRAINT [FK_Promotions_products] FOREIGN KEY ([prod_id]) REFERENCES [dbo].[products] ([prod_id]),
    CONSTRAINT [FK_Promotions_regions] FOREIGN KEY ([reg_id]) REFERENCES [dbo].[regions] ([reg_id])
);
GO

-- ============================================================
-- FUNCTIONS
-- ============================================================

CREATE FUNCTION [dbo].[fn_customer_tier]
(
    @LifeValue DECIMAL(10,2)
)
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @Tier VARCHAR(20);

    SET @Tier =
    CASE
        WHEN @LifeValue >= 100000 THEN 'Platinum'
        WHEN @LifeValue >= 50000 THEN 'Gold'
        WHEN @LifeValue >= 10000 THEN 'Silver'
        ELSE 'Bronze'
    END;

    RETURN @Tier;
END;
GO

CREATE FUNCTION [dbo].[fn_delivery_delay_days]
(
    @EstimatedDate DATETIME2,
    @ActualDate DATETIME2
)
RETURNS INT
AS
BEGIN
    RETURN DATEDIFF(DAY, @EstimatedDate, @ActualDate);
END;
GO

CREATE FUNCTION [dbo].[fn_return_percentage]
(
    @TotalOrders INT,
    @ReturnedOrders INT
)
RETURNS DECIMAL(10,2)
AS
BEGIN
    IF @TotalOrders = 0
        RETURN 0;

    RETURN CAST(@ReturnedOrders * 100.0 / @TotalOrders AS DECIMAL(10,2));
END;
GO

CREATE FUNCTION [dbo].[fn_get_customer_orders]
(
    @CustomerId VARCHAR(20)
)
RETURNS TABLE
AS
RETURN
(
    SELECT
        ord_id,
        ord_dt,
        ord_status,
        ord_total_amt
    FROM orders
    WHERE cust_id = @CustomerId
);
GO

-- ============================================================
-- VIEWS
-- ============================================================

CREATE VIEW [dbo].[vw_order_details] AS
SELECT
    o.ord_id,
    o.ord_dt,
    o.ord_status,
    o.ord_total_amt,
    c.cust_id,
    c.cust_email,
    c.loya_tier,
    r.reg_name,
    p.prod_id,
    p.prod_name,
    ol.qty,
    ol.unit_price_amt,
    ol.ln_total_amt
FROM orders o
INNER JOIN customers c ON o.cust_id = c.cust_id
INNER JOIN regions r ON o.reg_id = r.reg_id
INNER JOIN order_lines ol ON o.ord_id = ol.ord_id
INNER JOIN products p ON ol.prod_id = p.prod_id;
GO

CREATE VIEW [dbo].[vw_shipment_performance] AS
SELECT
    s.shp_id,
    s.ord_id,
    c.car_name,
    s.ship_dt,
    s.est_deli_dt,
    s.act_deli_dt,
    DATEDIFF(DAY, s.est_deli_dt, s.act_deli_dt) AS delay_days,
    CASE
        WHEN s.act_deli_dt <= s.est_deli_dt THEN 'On Time'
        ELSE 'Delayed'
    END AS delivery_status
FROM shipments s
INNER JOIN carriers c ON s.car_id = c.car_id;
GO

CREATE VIEW [dbo].[vw_inventory_health] AS
SELECT
    i.inv_id,
    p.prod_name,
    w.wh_name,
    r.reg_name,
    i.sfty_stock_qty,
    i.reord_pt_qty,
    i.lead_t_days,
    CASE
        WHEN i.sfty_stock_qty <= i.reord_pt_qty THEN 'Reorder Required'
        ELSE 'Healthy'
    END AS inventory_status
FROM inventories i
INNER JOIN products p ON i.prod_id = p.prod_id
INNER JOIN warehouses w ON i.wh_id = w.wh_id
INNER JOIN regions r ON i.reg_id = r.reg_id;
GO

CREATE VIEW [dbo].[vw_customer_summary] AS
SELECT
    cust_id,
    cust_email,
    loya_tier,
    life_val_amt,
    sign_up_dt,
    is_active_cust
FROM customers;
GO

CREATE VIEW [dbo].[vw_product_returns] AS
SELECT
    p.prod_id,
    p.prod_name,
    COUNT(r.rtn_id) AS total_returns,
    SUM(r.rfnd_amt) AS total_refund_amount
FROM products p
LEFT JOIN returns r ON p.prod_id = r.prod_id
GROUP BY p.prod_id, p.prod_name;
GO

-- ============================================================
-- STORED PROCEDURES
-- ============================================================

CREATE PROCEDURE [dbo].[usp_customer_order_history]
(
    @CustomerId VARCHAR(20)
)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        o.ord_id,
        o.ord_dt,
        o.ord_status,
        o.ord_total_amt
    FROM orders o
    WHERE o.cust_id = @CustomerId
    ORDER BY o.ord_dt DESC;
END;
GO