@echo off
cd /d %~dp0

:: Try 'localhost' first. If it fails, try '.\SQLEXPRESS'
set SERVER=localhost

echo ===========================================
echo STARTING SQL POC AUTOMATION (Windows Auth)
echo ===========================================

echo 1. Creating Login...
sqlcmd -S %SERVER% -E -i "01_login_file.sql" -C

echo 2. Creating Database, Tables and Objects...
sqlcmd -S %SERVER% -E -i "02_schema_file.sql" -C

echo 3. Inserting Data...
sqlcmd -S %SERVER% -E -i "03_insert_data.sql" -C

echo ===========================================
echo POC PROCESS COMPLETED
echo ===========================================
pause